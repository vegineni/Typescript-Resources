import {Component, ViewEncapsulation} from '@angular/core';

//declare var __moduleName: string;
@Component({
  selector: 'auction-application',
  moduleId:__moduleName,
  templateUrl: './application.html',
  styleUrls: ['./application.css'],
  encapsulation:ViewEncapsulation.None
})
export default class ApplicationComponent {}
