import {Component} from '@angular/core';

@Component({
  selector: 'auction-carousel',
  templateUrl: 'app/components/carousel/carousel.html'
})
export default class CarouselComponent {}
