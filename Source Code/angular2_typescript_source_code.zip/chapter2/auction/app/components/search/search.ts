import {Component} from '@angular/core';

@Component({
  selector: 'auction-search',
  templateUrl: 'app/components/search/search.html'
})
export default class SearchComponent {}
