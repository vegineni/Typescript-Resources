exports.name = 'ES5';

console.log('ES5 module is loaded');
