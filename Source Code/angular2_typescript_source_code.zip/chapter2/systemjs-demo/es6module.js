export let name = 'ES6';

console.log('ES6 module is loaded');
