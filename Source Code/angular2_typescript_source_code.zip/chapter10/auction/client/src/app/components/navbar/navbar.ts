import {Component} from '@angular/core';

@Component({
  selector: 'auction-navbar',
  templateUrl: 'navbar.html'
})
export default class NavbarComponent {}
