import { Component } from '@angular/core';

@Component({
  selector: 'auction-footer',
  templateUrl: 'footer.html'
})
export default class FooterComponent {}
