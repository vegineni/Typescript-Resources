// JQuery
interface JQuery {
  carousel(fn: string);
}

// Webpack
declare function require(path: string);
declare const webpack: {
  ENV: string
};
