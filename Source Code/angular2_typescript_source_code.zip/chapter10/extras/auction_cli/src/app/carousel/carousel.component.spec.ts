/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CarouselComponent } from './carousel.component';

describe('Component: Carousel', () => {
  it('should create an instance', () => {
    expect(true).toBeTruthy();
  });
});
