/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ProductDetailComponent } from './product-detail.component';

describe('Component: ProductDetail', () => {
  it('should create an instance', () => {
    //let component = new ProductDetailComponent();
    expect(true).toBeTruthy();
  });
});
