/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { FooterComponent } from './footer.component';

describe('Component: Footer', () => {
  it('should create an instance', () => {
    let component = new FooterComponent();
    expect(component).toBeTruthy();
  });
});
