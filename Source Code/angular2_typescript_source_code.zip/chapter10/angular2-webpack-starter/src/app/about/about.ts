import { Component } from '@angular/core';

@Component({
  selector: 'my-about',
  styleUrls: [ 'about.css' ],
  templateUrl: 'about.html',
})
export class About {}
