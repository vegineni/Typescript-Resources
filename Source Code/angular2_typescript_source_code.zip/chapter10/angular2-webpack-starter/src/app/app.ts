import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  styleUrls: [ 'app.css' ],
  templateUrl: 'app.html'
})
export class MyApp {}
