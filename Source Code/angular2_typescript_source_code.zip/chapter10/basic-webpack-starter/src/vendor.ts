import 'zone.js/dist/zone';
import 'reflect-metadata/Reflect.js';
import '@angular/http';
import '@angular/platform-browser-dynamic';
import '@angular/router';
