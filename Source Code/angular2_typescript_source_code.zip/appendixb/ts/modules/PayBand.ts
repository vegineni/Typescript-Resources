function getMaxSalary(band:number):number {
        return 100000;
    }

function getMinSalary(band:number):number {
        return 30000;
    }

