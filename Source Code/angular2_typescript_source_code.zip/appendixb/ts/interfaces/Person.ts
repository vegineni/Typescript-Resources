class Person  {

    constructor(public config: IPerson) {
    }
}