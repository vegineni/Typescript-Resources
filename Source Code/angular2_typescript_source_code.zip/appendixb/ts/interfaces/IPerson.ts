/**
 * Created by yfain11 on 7/6/15.
 */
interface IPerson {

    firstName: string;
    lastName: string;
    age: number;
    ssn: string;
}