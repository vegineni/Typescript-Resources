import {Component} from '@angular/core';
@Component({
  selector: 'auction-navbar',
  templateUrl: 'app/components/navbar/navbar.html'
})
export default class NavbarComponent {}
